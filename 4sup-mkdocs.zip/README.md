# 4SUP — MkDocs Material

## Pré-requisitos
- Python 3.9+
- `pip install mkdocs-material`

## Rodar localmente
```bash
pip install mkdocs-material
mkdocs serve
# abra http://127.0.0.1:8000
```

## Build
```bash
mkdocs build
# gera o site estático em site/
```

## Deploy (GitHub Pages)
```bash
pip install mkdocs-material mkdocs-git-revision-date-localized-plugin
mkdocs gh-deploy --force
```

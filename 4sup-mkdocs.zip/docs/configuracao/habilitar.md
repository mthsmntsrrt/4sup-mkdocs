# Habilitar o 4SUP no GesOper

1. **GesOper Operacional → Utilitários → Configuração → Configurações da Empresa**.  
2. Aba **Documentos e outros**: marque **Utiliza 4SUP**.  
3. Vá em **Cadastros → Postos** e preencha **Latitude** e **Longitude**.

!!! note "Coordenadas (Google Maps)"
    Clique com o botão direito no alfinete e copie as coordenadas. No GesOper, use **vírgula** como separador decimal.


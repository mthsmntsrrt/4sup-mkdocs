# Portal 4SUP — Agenda

## Manutenção
- Edite **data**, **turno**, **posto** e **supervisor**.
- **Cancelar** agendas quando necessário.
- Crie **Agendas Avulsas** escolhendo posto, supervisor, dia e turno.

## Geração em Massa
Gere agendas por período conforme periodicidades definidas (Posto/Contrato/Supervisor).  
Respeita ordem de supervisores e **escala**; se nenhum elegível existir, a agenda fica **sem supervisor**.


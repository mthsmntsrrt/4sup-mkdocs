# Portal 4SUP — Painel & Mapa

## Painel
Resumo por mês/ano com métricas de execução. Use filtros para investigar gargalos por posto/rota.

## Mapa
Acompanhe **agendas**, **localização** e **trajeto** dos supervisores em **tempo real**.


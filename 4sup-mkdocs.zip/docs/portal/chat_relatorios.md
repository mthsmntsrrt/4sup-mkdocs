# Portal 4SUP — Chat & Relatórios

## Chat
Comunicação **base ↔ supervisores** (texto, imagens, áudio, localização). Notificações no app.

## Relatórios
- **Supervisões**: período, veículos utilizados e paradas realizadas.
- **Checklists**: período, observações por item e exibição de imagens.


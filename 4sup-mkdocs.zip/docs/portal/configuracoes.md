# Portal 4SUP — Configurações

## Supervisão
- **Distância máxima para check-in** (m).
- Permissões de gerar agenda: *Avulsa*, *Periodicidade*, *Urgência* (site/app).
- **Alterar vistoria** pós check-out; **Assinatura** no check-out; **Escalas de outros postos**; **Turnos** e **tolerância**.

## Rota
- Início/fim de rota; **odômetro**; validação *Obrigatório/Justificado/Livre*.

## E-mail
Configuração de **SMTP** para envio de avisos de **SAC**.

## Aparelho
- Intervalo de atualização de **localização**.
- Tempo de **armazenamento** local (agendas, imagens, ocorrências).

## Outros
- **Encaminhamento de SAC** (responsável).
- **Lançar falta em dias de folga** (permissão).


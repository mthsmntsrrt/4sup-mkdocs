# Introdução ao 4SUP

O **GesOper 4SUP** é um sistema para **supervisão on-line** com duas frentes:
- **Portal Web 4SUP** (base operacional): agendas, painel, mapa, chat, relatórios e configurações.
- **Aplicativo 4SUP** (campo): rota, check-in/out com validação de proximidade, checklists, ocorrências/SAC e paradas.

> **Objetivo**: programar rotas inteligentes, registrar atividades em tempo real e acompanhar a operação de supervisão.

!!! tip "Como navegar"
    Use a barra lateral para acessar os tópicos. A busca (atalho **/**) encontra páginas e títulos rapidamente.

